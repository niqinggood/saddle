#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：kaggle 
@File    ：torch_bert_crf.py
@IDE     ：PyCharm 
@Author  ：patrick
@Date    ：2022/12/20 17:55 
'''
if __name__ == '__main__':
    exit()
    
  
  