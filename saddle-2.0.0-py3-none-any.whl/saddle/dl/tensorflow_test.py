#test reshape
import numpy as np
a = np.array([1,2,3,4,5,6,7,8]);print('a',a)
d = a.reshape((2,4)); print('d',d)
c = a.reshape((2,2,2));  print('c',c)  #这个就比较难了，分析下各个指代含义

#2019.09.09 -之后一周的任务很重，要在周五前看完红宝书，要
# 1 要在周五前看完红宝书；
# 2 权益类资产增长1w
# 3 专业上看完 lstm和attention 熟练运用
# 4  工作里的程序部署，误差统计 工作汇报，流程打通
# 5  leetcode 刷三道题

