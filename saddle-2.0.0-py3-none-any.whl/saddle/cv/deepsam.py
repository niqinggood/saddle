import os
import numpy as np
from PIL import Image
import torch
from torch.utils.data import DataLoader
from segment_anything import sam_model_registry
from torch.optim import Adam
import torch.nn as nn


import cv2
import numpy as np
from PIL import Image

def yolo_to_mask(image_path, label_path, output_mask_dir):
    """
    将 YOLOv8 分割掩码数据转换为 SAM 训练所需的掩码。
    :param image_path: 图像文件路径
    :param label_path: YOLOv8 标注文件路径
    :param output_mask_dir: 掩码保存目录
    """
    # 读取图像
    print('image_path', image_path)
    image = cv2.imread(image_path)
    if image is None:
        print(f"Error: Unable to read image {image_path}")
        return
    image_height, image_width = image.shape[:2]

    # 创建空白掩码
    mask = np.zeros((image_height, image_width), dtype=np.uint8)

    # 读取 YOLOv8 标注文件
    with open(label_path, "r") as f:
        lines = f.readlines()

    for line in lines:
        parts = list(map(float, line.strip().split()))
        class_id = int(parts[0])  # 类别 ID
        polygon = np.array(parts[1:], dtype=np.float32)  # 多边形顶点坐标

        # 将归一化坐标转换为像素坐标
        polygon = polygon.reshape(-1, 2) * [image_width, image_height]
        polygon = polygon.astype(np.int32)

        # 在掩码上绘制多边形
        cv2.fillPoly(mask, [polygon], color=1)

    # 保存掩码
    mask_image = Image.fromarray(mask * 255)  # 将掩码转换为图像
    mask_name = os.path.basename(image_path).replace(".jpg", ".png")  # 掩码文件名
    mask_path = os.path.join(output_mask_dir, mask_name)
    mask_image.save(mask_path)

    print(f"Saved mask: {mask_path}")

# 示例：批量转换 YOLO 数据
import logging
def convert_yolo_dataset(image_dir, label_dir, output_mask_dir):
    """
    批量转换 YOLO 数据集为 SAM 训练数据。
    :param image_dir: 图像目录
    :param label_dir: YOLO 标注目录
    :param output_mask_dir: 掩码保存目录
    """
    os.makedirs(output_mask_dir, exist_ok=True)
    #print("listdir:",os.listdir(image_dir))
    for image_name in os.listdir(image_dir):
        if not image_name.endswith(".jpg"):
            continue

        image_path = os.path.join(image_dir, image_name)
        label_name = image_name.replace(".jpg", ".txt")
        label_path = os.path.join(label_dir, label_name)
        # print("label path:",label_path)
        if os.path.exists(label_path):
            yolo_to_mask(image_path, label_path, output_mask_dir)
        else:
            print("not exists:",label_path)

# 自定义数据集
import torch
from torch.utils.data import Dataset
class SAMDataset(Dataset):
    def __init__(self, image_dir, mask_dir):
        self.image_dir = image_dir
        self.mask_dir = mask_dir
        self.image_names = os.listdir(image_dir)

    def __len__(self):
        return len(self.image_names)

    def __getitem__(self, idx):
        image_name = self.image_names[idx]
        image_path = os.path.join(self.image_dir, image_name)
        mask_name = image_name.replace(".jpg", ".png")
        mask_path = os.path.join(self.mask_dir, mask_name)

        # 加载图像和掩码
        image = np.array(Image.open(image_path)).astype(np.float32) / 255.0
        mask = np.array(Image.open(mask_path)).astype(np.float32) / 255.0

        # 检查图像通道数
        if len(image.shape) == 2:  # 灰度图像
            image = np.stack([image] * 3, axis=-1)  # 扩展为 3 通道

        # 转换为 PyTorch 张量
        image = torch.from_numpy(image).permute(2, 0, 1)  # (H, W, C) -> (C, H, W)
        mask = torch.from_numpy(mask).unsqueeze(0)  # (H, W) -> (1, H, W)

        return image, mask

# 训练函数
def train_sam(model, dataloader, epochs=10, lr=1e-4):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    optimizer = Adam(model.parameters(), lr=lr)
    criterion = nn.BCEWithLogitsLoss()  # 二分类交叉熵损失

    for epoch in range(epochs):
        model.train()
        for images, masks in dataloader:
            images, masks = images.to(device), masks.to(device)

            # 前向传播
            outputs = model(images, multimask_output=False)[0]  # 假设模型输出掩码
            loss = criterion(outputs, masks)

            # 反向传播
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        print(f"Epoch [{epoch+1}/{epochs}], Loss: {loss.item()}")

# 示例：训练 SAM
if __name__ == "__main__":
    image_dir   =   "E:\\ml_data\\deepseg\\brain\\train\\images"  # 图像目录
    label_dir   =   "E:\\ml_data\\deepseg\\brain\\train\\labels"  # 掩码目录
    mask_dir    = "./mask"  # 掩码保存目录

    #convert_yolo_dataset(image_dir, label_dir, mask_dir)

    # 加载模型
    sam = sam_model_registry["vit_b"](checkpoint="sam_vit_b.pth")

    # 创建数据集和数据加载器

    dataset     =   SAMDataset(image_dir, mask_dir)
    dataloader =    DataLoader(dataset, batch_size=8, shuffle=True)

    # 训练模型
    train_sam(sam, dataloader, epochs=10)