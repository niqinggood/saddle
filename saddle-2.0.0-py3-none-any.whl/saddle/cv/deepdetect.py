import torch
import torchvision
from torchvision.models.detection import FasterRCNN
from torchvision.models.detection.rpn import AnchorGenerator
from torchvision.ops import nms
from torchvision.transforms import functional as F
from torch.utils.data import DataLoader, Dataset
import os
import cv2
import numpy as np
import random

class YOLODataset(Dataset):
    """加载 YOLOv5 格式的数据集"""
    def __init__(self, image_dir, label_dir, transform=None):
        self.image_dir = image_dir
        self.label_dir = label_dir
        self.transform = transform
        image_file     = os.listdir(image_dir)
        #random.shuffle(image_file)
        self.image_files = image_file[ :600]

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        # 加载图像
        image_path = os.path.join(self.image_dir, self.image_files[idx])
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image = F.to_tensor(image)

        # 加载标注
        label_path = os.path.join(self.label_dir, self.image_files[idx].replace('.jpg', '.txt'))
        boxes = []
        labels = []
        with open(label_path, 'r') as f:
            for line in f.readlines():
                class_id, x_center, y_center, width, height = map(float, line.strip().split())
                # 转换为边界框坐标
                x1 = (x_center - width / 2) * image.shape[2]
                y1 = (y_center - height / 2) * image.shape[1]
                x2 = (x_center + width / 2) * image.shape[2]
                y2 = (y_center + height / 2) * image.shape[1]
                boxes.append([x1, y1, x2, y2])
                labels.append(int(class_id))

        # 检查边界框是否合法
        for box in boxes:
            assert box[0] < box[2] and box[1] < box[3], f"Invalid box coordinates: {box}"

        # 转换为 PyTorch 张量
        boxes = torch.as_tensor(boxes, dtype=torch.float32)
        labels = torch.as_tensor(labels, dtype=torch.int64)

        # 返回图像和标注
        target = {
            "boxes": boxes,
            "labels": labels
        }
        return image, target

def show_result(image,prediction ):
    from torchvision.utils import draw_bounding_boxes
    from torchvision.transforms.functional import to_pil_image

    # 绘制检测框
    boxes           = prediction['boxes'].cpu()
    labels          = prediction['labels'].cpu()
    image_with_boxes= draw_bounding_boxes(image, boxes, labels=labels)
    to_pil_image(image_with_boxes).show()

import datetime
def yolo_train( model_path ='yolov5s.pt',dataset_path = '/path/to/dataset.yaml',epochs=50,batch=16,project=datetime.datetime.now().strftime("%Y%m%d-%H%M%S") ):
    from ultralytics import YOLO

    # 加载预训练模型
    model = YOLO(model_path)
    # 训练模型
    results = model.train(
        data= dataset_path,
        epochs=epochs,
        imgsz=640,
        batch=batch,
        project=project,  # 指定保存目录的父目录
        device='cuda'  # 使用 GPU
    )
    # print('results:',results)
    return results

def yolo_inference(model_path='runs/train/exp/weights/best.pt', image_path='path/to/test_image.jpg',
                     result_path='path/to/save/results.jpg'):
    from ultralytics import YOLO

    # 加载训练好的模型
    model = YOLO(model_path)

    # 推理
    results = model(image_path)  # 传入图像路径

    # 可视化结果
    for result in results:
        # result.show()  # 显示结果
        result.save(filename=result_path)  # 保存结果


def yolo_to_coco(image_dir, label_dir, output_json, class_names):
    import json
    """
    将 YOLO 格式数据集转换为 COCO 格式。

    参数:
        image_dir (str): 图像文件夹路径。
        label_dir (str): 标签文件夹路径。
        output_json (str): 输出的 COCO 格式 JSON 文件路径。
        class_names (list): 类别名称列表，如 ['face']。
    """
    images = []
    annotations = []
    categories = [{"id": i + 1, "name": name} for i, name in enumerate(class_names)]

    image_id = 1
    annotation_id = 1

    for image_name in os.listdir(image_dir):
        if not image_name.endswith('.jpg'):
            continue

        # 添加图像信息
        image_path = os.path.join(image_dir, image_name)
        images.append({
            "id": image_id,
            "file_name": image_name,
            "width": 640,  # 根据实际图像尺寸修改
            "height": 480
        })

        # 添加标注信息
        label_path = os.path.join(label_dir, image_name.replace('.jpg', '.txt'))
        with open(label_path, 'r') as f:
            for line in f.readlines():
                class_id, x_center, y_center, width, height = map(float, line.strip().split())
                x_min = (x_center - width / 2) * 640
                y_min = (y_center - height / 2) * 480
                x_max = (x_center + width / 2) * 640
                y_max = (y_center + height / 2) * 480

                annotations.append({
                    "id": annotation_id,
                    "image_id": image_id,
                    "category_id": int(class_id) + 1,
                    "bbox": [x_min, y_min, x_max - x_min, y_max - y_min],
                    "area": (x_max - x_min) * (y_max - y_min),
                    "iscrowd": 0
                })
                annotation_id += 1

        image_id += 1

    # 保存为 COCO 格式
    coco_format = {
        "images": images,
        "annotations": annotations,
        "categories": categories
    }
    with open(output_json, 'w') as f:
        json.dump(coco_format, f)



# 转换训练集和验证集
# yolo_to_coco('/path/to/dataset/images/train', '/path/to/dataset/labels/train',
#                  '/path/to/dataset/annotations/train.json')
# yolo_to_coco('/path/to/dataset/images/val', '/path/to/dataset/labels/val', '/path/to/dataset/annotations/val.json')




def mmdet_train(config_file, data_root, work_dir, num_classes, max_epochs=50):
    from mmdet.apis import set_random_seed
    from mmdet.datasets import build_dataset
    from mmdet.models import build_detector
    from mmdet.apis import train_detector
    from mmcv import Config
    # 加载配置文件
    cfg = Config.fromfile(config_file)

    # 修改配置
    cfg.dataset_type = 'CocoDataset'
    cfg.data_root = data_root
    cfg.data.train.ann_file = f'{data_root}/annotations/train.json'
    cfg.data.train.img_prefix = f'{data_root}/images/train'
    cfg.data.val.ann_file = f'{data_root}/annotations/val.json'
    cfg.data.val.img_prefix = f'{data_root}/images/val'
    cfg.data.test.ann_file = f'{data_root}/annotations/val.json'
    cfg.data.test.img_prefix = f'{data_root}/images/val'
    cfg.model.roi_head.bbox_head.num_classes = num_classes
    cfg.work_dir = work_dir  # 指定 work_dir
    cfg.runner.max_epochs = max_epochs
    cfg.seed = 0
    set_random_seed(0, deterministic=False)

    # 构建数据集
    datasets = [build_dataset(cfg.data.train)]

    # 构建模型
    model = build_detector(cfg.model)

    # 训练模型
    train_detector(model, datasets, cfg, distributed=False, validate=True)

    print(f"训练完成，模型保存在 {work_dir}")


def mmdet_inference(config_file, checkpoint_file, image_path, output_file):
    """
    使用 MMDetection 进行推理。

    参数:
        config_file (str): 配置文件路径。
        checkpoint_file (str): 模型权重文件路径。
        image_path (str): 测试图像路径。
        output_file (str): 结果保存路径。
    """
    # 加载模型
    model = init_detector(config_file, checkpoint_file, device='cuda')

    # 推理
    result = inference_detector(model, image_path)

    # 可视化并保存结果
    model.show_result(image_path, result, out_file=output_file)

    print(f"推理结果已保存到 {output_file}")



def mmdet_evaluate(config_file, checkpoint_file, data_root):
    from mmdet.apis import init_detector, inference_detector, show_result_pyplot
    from mmdet.apis import set_random_seed, train_detector
    from mmdet.datasets import build_dataset
    from mmdet.apis import single_gpu_test
    from mmcv.parallel import MMDataParallel
    from mmdet.datasets import build_dataloader
    """
    使用 MMDetection 评估模型。

    参数:
        config_file (str): 配置文件路径。
        checkpoint_file (str): 模型权重文件路径。
        data_root (str): 数据集根目录。
    """
    # 加载配置文件
    cfg = Config.fromfile(config_file)

    # 修改配置
    cfg.data.test.ann_file = f'{data_root}/annotations/val.json'
    cfg.data.test.img_prefix = f'{data_root}/images/val'

    # 构建数据集
    dataset = build_dataset(cfg.data.test)

    # 构建数据加载器
    data_loader = build_dataloader(
        dataset,
        samples_per_gpu=1,
        workers_per_gpu=1,
        dist=False,
        shuffle=False
    )

    # 加载模型
    model = init_detector(config_file, checkpoint_file, device='cuda')
    model = MMDataParallel(model, device_ids=[0])

    # 评估
    outputs = single_gpu_test(model, data_loader)

    # 计算 mAP
    eval_results = dataset.evaluate(outputs, metric='bbox')
    print("评估结果:", eval_results)

def mmdec_main():
    # 数据集路径
    data_root = r'D:\bak\FDDB\yolo_dataset'
    work_dir = r'D:\bak\FDDB\work_dir'
    config_file = 'configs/faster_rcnn/faster_rcnn_r50_fpn_1x_coco.py'
    class_names = ['face']

    # 1. 数据准备：YOLO 转 COCO
    print("开始数据准备...")
    yolo_to_coco(
        image_dir=os.path.join(data_root, 'images', 'train'),
        label_dir=os.path.join(data_root, 'labels', 'train'),
        output_json=os.path.join(data_root, 'annotations', 'train.json'),
        class_names=class_names
    )
    yolo_to_coco(
        image_dir=os.path.join(data_root, 'images', 'val'),
        label_dir=os.path.join(data_root, 'labels', 'val'),
        output_json=os.path.join(data_root, 'annotations', 'val.json'),
        class_names=class_names
    )
    print("数据准备完成！")

    # 2. 训练模型
    print("开始训练模型...")
    mmdet_train(
        config_file=config_file,
        data_root=data_root,
        work_dir=work_dir,
        num_classes=len(class_names),
        max_epochs=50
    )
    print("模型训练完成！")

    # 3. 推理
    print("开始推理...")
    mmdet_inference(
        config_file=config_file,
        checkpoint_file=os.path.join(work_dir, 'latest.pth'),
        image_path=os.path.join(data_root, 'images', 'val', 'img3.jpg'),
        output_file=os.path.join(data_root, 'results', 'result.jpg')
    )
    # print("推理完成！")

    # 4. 评估
    print("开始评估模型...")
    mmdet_evaluate(
        config_file=config_file,
        checkpoint_file=os.path.join(work_dir, 'latest.pth'),
        data_root=data_root
    )
    # logging.info("评估完成！")


if __name__ == "__main__":
    # 1. 训练模型
    results = yolo_train(model_path ='./runs/detect/train3/weights/best.pt',dataset_path='./dataset.yaml',epochs=1,batch=32)

    # result_dict['train_result'] = results
    if hasattr(results, 'results_dict'):
        # YOLOv5 的处理方式
        mAP_50 = results.results_dict.get('metrics/mAP_0.5', None)
        mAP_50_95 = results.results_dict.get('metrics/mAP50-95(B)')
    # logging.info(  mAP_50_95 )
    # # 2. 推理测试
    # yolo_inference(
    #     model_path='./runs/detect/train4/weights/best.pt',  # 训练好的模型路径
    #     image_path= './test.png',  # 测试图像路径  'F:\\work\\hms_ml_project\\red.jpg',#
    #     result_path='./result_det.jpg'  # 结果保存路径
    # )

    # yolo_inference(  model_path ='./best.pt',image_path ='D:\bak\FDDB\yolo_dataset\images\val\86.jpg',
    #                    result_path='./test_results.jpg' )
    #

    exit()
    # 加载数据集
    base_dir = 'D:\\bak\\FDDB\\yolo_dataset'
    train_dataset = YOLODataset(image_dir=os.path.join(base_dir, 'images', 'train'),
                                label_dir=os.path.join(base_dir, 'labels', 'train'))
    val_dataset    = YOLODataset(image_dir=os.path.join(base_dir, 'images', 'val'),
                              label_dir=os.path.join(base_dir, 'labels', 'val'))

    # 调用训练函数
    mmdet_train(
        config_file='configs/faster_rcnn/faster_rcnn_r50_fpn_1x_coco.py',
        data_root='/path/to/dataset',
        work_dir='/path/to/work_dir',  # 指定 work_dir
        num_classes=1,
        max_epochs=50
    )


    exit(  )


    # 初始化模型
    model = get_faster_rcnn2(num_classes=2)  # 1 个类别（人脸） + 背景   ##get_ssd(2)#
    model.to('cuda')
    # 训练和评估模型
    #evaluate_model(model, val_loader, 'cuda')
    train_detect_model(model, train_loader, val_loader, num_epochs=4)