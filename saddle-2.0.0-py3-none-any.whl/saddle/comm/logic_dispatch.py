import  argparse
import  json
import  copy
import  pandas as pd
import  numpy as np
from    typing import List
import  logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

from sklearn.model_selection import train_test_split

def calc_psi(actual_array, expected_array, buckets=10, type="equal_f"):  # actual:test, expected:base
    """
    功能: 计算PSI值，并输出实际和预期占比分布
    :param actual_array: Array或series，代表真实数据，如测试集模型得分 # test1
    :param expect_array: Array或series，代表期望数据，如训练集模型得分 # base
    :param buckets: 分段数
    :param type={"equal_d","equal_f"} 代表{"等宽分箱"，"等频分箱"}
    :return:
        PSI_value: float，PSI值
        PSI_df:DataFrame :分桶计算的细节
    """
    # step1:分箱
    actual_array = actual_array.dropna()  # 删除缺失值
    expected_array = expected_array.dropna()

    # 获取分箱的边界
    first_edge = expected_array.min()
    last_edge = expected_array.max()
    # 等频分箱
    import numpy as np
    if type == "equal_f":
        breakpoints = np.quantile(expected_array, np.linspace(start=0, stop=1, num=(buckets + 1)))  # 获取分位数为切点，每段频率相等
        breakpoints[0] = -float("inf")  # 扩展上下边界
        breakpoints[buckets] = float("inf")
    # 等宽分箱
    elif type == "equal_d":
        breakpoints = np.linspace(start=first_edge, stop=last_edge, num=(buckets + 1))  # 按数值区间均匀分段
        breakpoints[0] = -float("inf")  # 扩展上下边界
        breakpoints[buckets] = float("inf")
    else:
        print("Error: type is error")
    # 获取分箱切点列表
    break_cuts = [[breakpoints[edge_num], breakpoints[edge_num + 1]] for edge_num in range(0, buckets)]

    # step2:计算每个分箱内的样本数和样本频率
    expected_cnt = np.histogram(expected_array, bins=breakpoints, density=False)[0]  # 频数
    expected_percents = expected_cnt / sum(expected_cnt)  # 频率
    actual_cnt = np.histogram(actual_array, bins=breakpoints, density=False)[0]
    actual_percents = actual_cnt / sum(actual_cnt)

    # step3:计算PSI
    # 计算每个分箱内的值
    def sub_psi(test, base):
        # 防止分母为np.log底数为0
        if base == 0:
            base = 0.0001
        if test == 0:
            test = 0.0001
        # 计算每个分箱内的值
        value = (test - base) * np.log(test / base)
        return (value)
        # 所有分箱的计算结果相加，即PSI

    SUB_PSI_value = []
    for i in range(0, len(expected_percents)):
        SUB_PSI_value.append(sub_psi(actual_percents[i], expected_percents[i]))

    # 计算完成PSI
    PSI_value = sum(SUB_PSI_value)
    # 保留计算细节：每个分箱的计数、频率及SUB_PSI
    # SUB_PSI_value=np.round(np.array(SUB_PSI_value),4)  #保留小数
    PSI_df = pd.concat([pd.DataFrame([break_cuts]).T, pd.Series(expected_cnt), pd.Series(actual_cnt), pd.Series(expected_percents), pd.Series(actual_percents), pd.Series(SUB_PSI_value)], axis=1, join="outer")
    PSI_df.columns = ["cuts", "expect_cnt", "actual_cnt", "expect_percents", "actual_percents", "sub_psi"]
    return (PSI_value, PSI_df)


def get_describe(train_df: pd.DataFrame, indie_df: pd.DataFrame, xcols: List[str], ycol: str):
    logging.info('begin get_describe,get train&indie desribe_df')
    tmp_train_df = copy.deepcopy(train_df)[xcols + [ycol]]
    tmp_indie_df = copy.deepcopy(indie_df)[xcols + [ycol]]
    logging.info('dtypes:%s', tmp_train_df.dtypes)
    train_sum_df = tmp_train_df.isnull().sum().to_frame().rename(columns={0: 'train_null_cnt'})
    train_sum_df['train_null_ratio'] = train_sum_df['train_null_cnt'] / len(train_df)
    indie_sum_df = tmp_indie_df.isnull().sum().to_frame().rename(columns={0: 'indie_null_cnt'})
    indie_sum_df['indie_null_ratio'] = indie_sum_df['indie_null_cnt'] / len(indie_df)
    num_cols    = tmp_train_df.describe().columns
    pearson_df  = tmp_train_df[num_cols].corrwith(tmp_train_df[ycol], method='pearson').to_frame().rename(columns={0: ycol + "_pearson"})
    spearman_df = tmp_train_df[num_cols].fillna(0).corrwith(tmp_train_df[ycol], method='spearman').to_frame().rename(columns={0: ycol + "_spearman"})
    describe_df = tmp_train_df.describe().T
    describe_df = describe_df.merge(pearson_df, left_index=True, right_index=True).merge(spearman_df, left_index=True, right_index=True).merge(train_sum_df, left_index=True, right_index=True).merge(indie_sum_df, left_index=True, right_index=True)
    describe_df = describe_df.reset_index().rename(columns={"index": "feature"})
    logging.info('finish get_describe,get train&indie desribe_df')
    return describe_df


def str_to_list(obj):
    if isinstance(obj, list):
        return obj
    if isinstance(obj, str):
        return obj.split(',')


def fillna_by_algo(df: pd.DataFrame, algo: str):
    '''
    df 中的所有列都应该是数值类型
    '''
    algo = algo.lower()
    if algo not in ["lightgbm", "xgboost"]:
        for col in df.columns:
            df[col] = df[col].fillna(df[col].mean())
    return df

def dropna_by_algo(df: pd.DataFrame, algo: str, subset=None):
    '''
    df 中的所有列都应该是数值类型
    '''
    tmp_df = copy.deepcopy(df)
    algo = algo.lower()
    if algo not in ["lightgbm", "xgboost"]:
        if subset != None:
            return tmp_df.dropna(subset=subset)
        else:
            return tmp_df.dropna()
    return tmp_df


def iter_fillna_bykeymean(in_df, features, key='LOT_ID'):
    ret_df = []
    keys = in_df[key].unique()
    for k in keys:
        tmp_df = in_df[in_df[key] == k]
        if len(tmp_df) == 0:
            continue
        for f in features:
            tmp_df[f] = tmp_df[f].fillna(tmp_df[f].dropna().mean())
        ret_df.append(tmp_df)
    ret_df = pd.concat(ret_df, axis=0)
    return ret_df


demo_code_str = '''
def complicated_case_func(f_input):
    f_input = f_input
    return f_input'''


def run_flexible_code(code_str, code_input):
    exec(code_str, globals())
    ret = eval('complicated_case_func')(code_input)
    return ret


def save_data(df: pd.DataFrame,  data_tag: str, save_dir: str, use_mlflow=None, use_source=None):
    # local_dir = os.path.join(save_dir, "dataset_" + train_name)
    os.makedirs(save_dir, exist_ok=True)
    local_file = os.path.join(save_dir, data_tag + ".csv")
    df.to_csv(local_file, index=False)
    if use_mlflow != None:
        import mlflow
        mlflow.log_artifact(local_file, artifact_path=use_source)


import datetime
seed = datetime.datetime.now().microsecond
import math
import copy
import random
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, mean_absolute_percentage_error
import joblib
import tqdm

from sklearn import tree
from sklearn import svm
from sklearn import neighbors
from sklearn import ensemble



def build_regressor_model(name='LR', args_params={}):
    logging.info("begin build regressor model algo[%s] model_params[%s]",name,args_params)
    if name in ['dcn','tcn','autogluon','widedeep']:
        model_params = args_params
    else:
        model_params = {}

    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.tree import ExtraTreeRegressor
    from sklearn.ensemble import BaggingRegressor
    from sklearn import linear_model
    from xgboost import XGBRegressor
    from lightgbm import LGBMRegressor
    from catboost import CatBoostRegressor
    from sklearn.cross_decomposition import PLSRegression
    name = name.lower()
    logging.info("build regressor %s model",name)
    if name == 'lr':              model = linear_model.LinearRegression(**model_params)
    elif name == 'lasso':         model = linear_model.Lasso(**model_params)  ### 线性回归 ###
    elif name == 'ridge':         model = linear_model.Ridge(**model_params)  ### 线性回归 ###
    elif name == 'pls':           model = PLSRegression(**model_params)
    elif name == 'elasticnet':    model = linear_model.ElasticNet(**model_params)  ### 线性回归 ###
    elif name == 'dt':            model = tree.DecisionTreeRegressor(**model_params)  # criterion="mae"
    elif name == 'linearsvm':     model = svm.SVR(**{k: v for d in [model_params, {'kernel': "linear", 'C': 0.025}] for k, v in d.items()})  ### SVM回归 ###
    elif name == 'rbfsvm':        model = svm.SVR(**{k: v for d in [model_params, {'kernel': 'rbf'}] for k, v in d.items()})
    elif name == 'knn':           model = neighbors.KNeighborsRegressor(**model_params)  ### KNN回归 ###
    elif name == 'randomforest':  model = ensemble.RandomForestRegressor(n_estimators=21)  # 用20个决策树 ### 随机森林回归 ###
    elif name == 'adaboost':      model = ensemble.AdaBoostRegressor(**model_params)  # 用50个决策树### Adaboost回归 ###
    elif name == 'gbdt':          model = ensemble.GradientBoostingRegressor(**model_params)  # 用100个决策树 ### GBRT回归 ###
    elif name == 'bagging':       model = BaggingRegressor(**model_params)  ### Bagging回归 ###
    elif name == 'extratree':     model = ExtraTreeRegressor(**model_params)  ### ExtraTree极端随机树回归 ###
    elif name == 'xgboost':       model = XGBRegressor(**model_params)
    elif name == 'lightgbm':      model = LGBMRegressor(**{k: v for d in [model_params, {'verbose': -1}] for k, v in d.items() })  # k:v for d in [model_params,{'num_boost_round':100}] for k,v in d.items() }
    elif name == 'catboost':      model = CatBoostRegressor(**{k: v for d in [model_params, {'silent': True}] for k, v in d.items() })   # objective='binary',metrics='binary_logloss',n_estimators=101
    elif name == "autogluon":
        from ..automl.autogluon import AutogluonWrapper
        model = AutogluonWrapper(presets="medium_quality",model_type="regression")
    elif name == "dcn" :
        from ..dl.deepreg import DCNWrapper, TCNWrapper, WideDeepMWrapper
        model = DCNWrapper(num_continuous=model_params.num_continuous,num_categories=model_params.num_categories,
                                            embedding_dims=[(8,25)]*model_params.num_continuous,num_cross_layers=2,deep_layer_dims=[64,8,8,8],output_dim=1,task='regression',epochs=560,batch_size=8 )
    elif name == 'tcn' :
        from ..dl.deepreg import DCNWrapper, TCNWrapper, WideDeepMWrapper
        model  = TCNWrapper(input_size=len( model_params.xcols),output_size=1,num_layers=3,base_channels=10,kernel_size=3,dropout=0.2,epochs=10,task='regression')
    elif name =='widedeep':
        from ..dl.deepreg import DCNWrapper, TCNWrapper, WideDeepMWrapper
        model = WideDeepMWrapper( embed_cols=model_params.categoriesxcolumns,
                                                            continuous_cols = model_params.continuousxcolumns,
                                                            crossed_cols = None,
                                                            text_cols    = model_params.textxcolumns,
                                                            img_col      = model_params.imagexcolumns,
                                                            img_path     = "images",
                                                            objective    = "regression",
                                                            device       ="cpu",n_epochs =10,
                                                            sorted_xcols =model_params.xcols )
    else:
        logging.info("unknow algo[%s] cannot build new model",name)
    logging.info("finish build_regressor model")
    return model


def build_classifier_model(name, model_params={}):
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.svm import SVC
    from sklearn.gaussian_process import GaussianProcessClassifier
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
    from sklearn.neural_network import MLPClassifier
    from sklearn.svm import LinearSVC
    from sklearn.ensemble import GradientBoostingClassifier
    from sklearn.naive_bayes import MultinomialNB
    from sklearn.linear_model import LogisticRegression, RidgeClassifier
    from xgboost import XGBClassifier
    from lightgbm import LGBMClassifier
    from sklearn.naive_bayes import GaussianNB, BernoulliNB
    from catboost import CatBoostClassifier
    from sklearn.ensemble import BaggingClassifier
    name = name.lower()

    if name not in ['lr','knn','ridge','mlp','linearsvm','rbfsvm','dt','naivebayes','qda','gaussianprocess','bernoullinb','multinomialnb','randomforest','adaboost','gbdt','xgboost', 'lightgbm','catboost']:
        logging.error('donnot support build classfier model[%s]',name)
        return None

    if name == 'lr':                model = LogisticRegression(**model_params)  # penalty='l1'
    if name == 'knn':               model = KNeighborsClassifier(7)
    if name == 'ridge':             model = RidgeClassifier(**model_params)  ### 线性回归 ###
    if name == 'mlp':               model = MLPClassifier(hidden_layer_sizes=(50, 50), activation='relu', max_iter=300, alpha=0.01)
    if name == 'linearsvm':         model = SVC(**{k: v for d in [model_params, {'kernel': "linear", 'C': 0.025}] for k, v in d.items()})  # model_params   #kernel="linear",
    if name == 'rbfsvm':            model = SVC(**{k: v for d in [model_params, {'kernel': 'rbf'}] for k, v in d.items()})  # ,gamma=2, C=1
    if name == 'dt':                model = DecisionTreeClassifier(**model_params)
    if name == 'naivebayes':        model = GaussianNB(**model_params)
    if name == 'qda':               model = QuadraticDiscriminantAnalysis(**model_params)
    if name == 'gaussianprocess':   model = GaussianProcessClassifier(**model_params)
    if name == 'bernoullinb':       model = BernoulliNB(**model_params)
    if name == 'multinomialnb':     model = MultinomialNB(alpha=1, class_prior=None, fit_prior=True)
    if name == 'randomforest':      model = ensemble.RandomForestClassifier(max_depth=5, n_estimators=101)
    if name == 'adaboost':          model = ensemble.AdaBoostClassifier(**model_params)
    if name == 'gbdt':              model = GradientBoostingClassifier(**model_params)
    if name == 'xgboost':           model = XGBClassifier(**model_params)
    if name == 'lightgbm':          model = LGBMClassifier(**{k: v for d in [model_params, {'verbose': -1}] for k, v in d.items() })  # objective='binary',metrics='binary_logloss',n_estimators=101
    if name == 'catboost':          model = CatBoostClassifier(**{k: v for d in [model_params, {'silent': True}] for k, v in d.items() })    # objective='binary',metrics='binary_logloss',n_estimators=101
    # if name =='fm':               model = pylibfm.FM()
    return model


def build_train_model(X, y, name='RandomForestRegressor', type='classifier', model_params={}):
    logging.info('begin build_train_model[%s] algo[%s] type[%s] model_params[%s]',name,name,type,str(model_params))
    if type in ['cla', 'cl','clf', 'classifier']:
        model = build_classifier_model(name, model_params)  # # 指定模型
    elif type in ['reg', 'regressor', 'regression']:
        model = build_regressor_model(name, model_params)  # # 指定模型
    else:
        logging.error("in build_train_model,but meet error model type[%s] ",type)
        return None
    if model ==None: return None
    logging.info("sample_len[%s]",len(y))
    model.fit(X, y)
    logging.info('finish build_train_model[%s]', name)
    return model


default_reg_params = {
    'lr': {'fit_intercept': [True, False]},
    'lasso': {'alpha': list(np.logspace(-3, 2, 10))},
    'ridge': {'alpha': list(np.logspace(-3, 2, 10))},
    'pls': {'n_components': [2, 3, 4, 5, 6, 7, 8]},
    'elasticnet': {"alpha": [0.5, 0.8, 1, 1.5, 2], "l1_ratio": [0.1, 0.3, 0.5, 0.7, 0.9]},
    'xgboost': {'reg_alpha': [0.01, 0.1, 0.05], 'reg_lambda': [0.01, 0.1, 0.05], 'max_depth': list(range(2, 6, 1)), 'n_estimators': [101, 501, 1001, 3001], 'scale_pos_weight': list(range(1, 3, 1))},
    'lightgbm': {'reg_alpha': [0.01, 0.1, 0.05], 'reg_lambda': [0.01, 0.1, 0.05], 'max_depth': list(range(2, 6, 1)), 'n_estimators': [101, 501, 1001, 3001, 5001], 'num_leaves': [5, 11, 21, 31], 'scale_pos_weight': list(range(1, 4, 1)), 'feature_fraction': [0.5, 0.7, 0.9], 'bagging_fraction': [0.6, 0.8]},
    'deeplearn': {},
    'selfalgo': {},
    'catboost':{}
}
default_clf_params = {
    'lr': {'C': [0.01, 0.1, 0.2, 0.5, 1, 1.5, 2, 3, 4, 5], 'solver': ['liblinear', 'saga']},
    'lasso': {'alpha': np.logspace(-3, 2, 10), 'fit_intercept': [True, False]},
    'ridge': {'alpha': np.logspace(-3, 2, 10), 'fit_intercept': [True, False]},
    'elasticnet': {'alpha': np.logspace(-3, 2, 10), 'fit_intercept': [True, False], 'l1_ratio': [0.01, 0.1, 0.3, 0.5, 0.6, 0.7, 0.9]},
    'xgboost': {'reg_alpha': [0.01, 0.05, 0.1], 'reg_lambda': [0.01, 0.05, 0.1], 'max_depth': list(range(2, 5, 1)), 'n_estimators': [101, 501, 1001], 'num_leaves': [5, 11, 21, 31], 'learning_rate': list(np.arange(0.01, 0.3, 0.05)), 'scale_pos_weight': list(range(1, 5, 1))},
    'lightgbm': {'reg_alpha': [0.01, 0.05, 0.1], 'reg_lambda': [0.01, 0.05, 0.1], 'max_depth': list(range(2, 5, 1)), 'num_boost_round': [100, 200], 'n_estimators': [101, 501, 1001, 3001, 5001], 'num_leaves': [5, 11, 21, 31], 'scale_pos_weight': list(range(1, 5, 1)), 'feature_fraction': [0.6, 0.7, 0.8], 'bagging_fraction': [0.6, 0.7, 0.8, 0.9]},
    'deeplearn': {},
    'catboost':{}
}


def build_tuning_mode(X, y, opt_score=None, name='Ridge', type='reg', tuning_dict={}, search_algo=''):
    logging.info('in build tuning mode algo_name:%s tuning_dict:%s', name,  tuning_dict)
    if name == 'selfalgo':
        return {}, build_regressor_model(name, {"x_order": tuning_dict['x_order'], "algo_func": tuning_dict['algo_func']})
    if tuning_dict != None:  tuning_dict = {k: v for k, v in tuning_dict.items() if v != '' and v != None}
    search_algo = search_algo.lower()
    name = name.lower()
    best_model, best_params = None, None
    if type in ['cla', 'clf', 'cl', 'classifier']:
        metric_scoring = 'f1_score' if opt_score == None else opt_score
        search_params = tuning_dict if tuning_dict != None and tuning_dict != {} else default_clf_params[name]  # [default_clf_params[name], tuning_dict]
    if type in ['reg', 'regressor', 'Regressor','regression']:
        metric_scoring = 'mean_absolute_error' if opt_score == None else opt_score
        search_params = tuning_dict if tuning_dict != None and tuning_dict != {} else default_reg_params.setdefault(name, {})  # default_reg_params[name]
    logging.info('search parms:%s', search_params)

    if search_algo in ['gridsearch','grid']:
        logging.info("search algo %s",search_algo)
        from sklearn.model_selection import GridSearchCV
        if type in ['cla', 'clf', 'cl', 'classifier']:
            model = build_classifier_model(name)
        if type in ['reg', 'regressor', 'Regressor','regression']:
            model = build_regressor_model(name)

        tmp_metric_scoring = {"f1_score": "f1_weighted", "mean_absolute_error": "neg_mean_absolute_error"}[metric_scoring]
        gs = GridSearchCV(model, param_grid=search_params, cv=5, scoring=tmp_metric_scoring, n_jobs=-1, verbose=2)
        gs.fit(X, y)
        logging.info('gs %s', gs.best_params_)
        best_params, best_model = gs.best_params_, gs.best_estimator_

    ###below is hypopera for Random and TPE optimize
    def object(tmp_params):
        logging.info('begin tuning object: x_len %d, y_len %d  tmp_params[%s]' % (len(X), len(y),str(tmp_params)))
        cnt = len(y)
        candiat_idx = list(range(0, cnt))
        random.shuffle(candiat_idx)
        val_idx = candiat_idx[: int(0.2 * cnt)]
        train_x, train_y, val_x, val_y = [], [], [], []
        for i in range(0, cnt):
            if i in val_idx:
                val_x.append(X[i]);
                val_y.append(y[i])
            else:
                train_x.append(X[i]);
                train_y.append(y[i])
        logging.info("finished train[%s]/val[%s] split",len(train_x),len(val_x))
        model = build_train_model(train_x, train_y, name, type, tmp_params)
        preds = model.predict(val_x)
        import sklearn.metrics as metr
        loss = getattr(metr, metric_scoring)(val_y, preds) if metric_scoring == "mean_absolute_error" else getattr(metr, metric_scoring)(val_y, preds, average="weighted")

        if type in ['cla', 'clf', 'cl', 'classifier']:            ret = {'loss': -1 * loss, 'status': STATUS_OK}
        if type in ['reg', 'regressor', 'Regressor','regression']:             ret = {'loss': loss, 'status': STATUS_OK}
        logging.info("obj ret:%s",ret)
        return ret

    if search_algo in ['random', 'tpe']:
        logging.info("search_algo %s",search_algo)
        from hyperopt import hp, fmin, tpe, STATUS_OK, Trials, rand, space_eval
        space = {k: hp.choice(k, v) for k, v in search_params.items()}
        trials = Trials()
        # best   = { 'random': fmin( object, space, algo=rand.suggest, trials=trials, verbose=0, max_evals= 10),
        #            'tpe':    fmin( object, space, algo=tpe.suggest,  trials=trials, verbose=0, max_evals=10 ) }.setdefault( search_algo.lower(), None   )
        logging.info("search algo[%s] space[%s] ",search_algo,space)
        if search_algo.lower() in ['tpe']:
            best_vals = fmin(object, space, algo=tpe.suggest, trials=trials, verbose=0, max_evals=10)
        if search_algo.lower() in ['random']:
            best_vals = fmin(object, space, algo=rand.suggest, trials=trials, verbose=0, max_evals=10)
        best_params = space_eval(space, best_vals)
        logging.info( '%s best_params:%s',name, best_params)
        best_model = build_train_model(X, y, name, type, best_params)
    return best_params, best_model


def multi_models_predicts(models_dict, in_df, keys, xcols, ycol, deploy=False,data_type=''):  # , result_label='stata/preds'
    logging.info('begin new multi_models_predicts %s: keys%s  xcols%s ycol[%s]',data_type,keys, xcols, ycol)
    sample_df = copy.deepcopy(in_df)
    if isinstance(ycol,list):
        ycol = ycol[0]
        logging.info("we only can process one y predict")
    slim_df             = sample_df[ xcols + [ycol]  ] if ycol in sample_df.columns else sample_df[  xcols ]
    slim_df['tmp_key']  = list( range( 0,len(slim_df))  )
    logging.info(  "models_dict keys==preds_cols:%s",models_dict.keys() )
    for name in models_dict.keys():
        logging.info("begin predict model[%s] keys%s ",name,keys)
        model   = models_dict[name]
        logging.info("%s model:%s",name,model)
        repl_xcol  = model.x_order if name == "selfalgo" else xcols
        logging.info("repl_xcols:%s",repl_xcol )
        logging.info("sampledf columns:%s",list( sample_df.columns )  )
        if deploy:
            logging.info("predict_feature_key_values:%s",slim_df)
        logging.info("begin dropna base model[%s] repl_xcol%s",name,repl_xcol)
        tmp_df    = dropna_by_algo( slim_df,name,subset=repl_xcol )
        logging.info( "finish dropna base %s \n%s",name,tmp_df.head()  )
        if len(tmp_df) ==0:
            logging.error(  "x input len is 0,error please check,model[%s]",name )
        in_x            = tmp_df[ repl_xcol ].values
        preds           = model.predict(in_x)
        logging.info("preds:%s",preds)
        logging.info( "len tmp_df:%s preds:%s %s", len(tmp_df),len( preds ) ,type( preds))
        tmp_df[name]    = preds  #
        logging.info("slim_df len:%s   sample_df:%s", len(slim_df),len(sample_df))
        slim_df         = pd.merge(slim_df,tmp_df[[ "tmp_key",name ]],on=['tmp_key'],how='left')
        sample_df[name] = slim_df[name].tolist()
    logging.info("slim_df:%s",slim_df.head() )
    logging.info("sample_df:\n%s",sample_df.head())
    logging.info("finish new multimodels_predis %s,keys %s xcols%s ycol%s",data_type,keys,xcols,ycol)
    return sample_df


def multi_preds_statas(preds_df, names=[], ycol='y', small_excep=-5, big_except=5,model_type='reg'):
    result_df = []
    if ycol not in preds_df:
        logging.error("ycol not in preds_df,your data maybe indie")
        return pd.DataFrame()
    for name in names:
        tmp_df = preds_df.dropna(subset=[name,ycol],how='any')
        tmp_stata_df = get_statas_df(tmp_df[ycol], tmp_df[name], name, small_excep, big_except,model_type) if len(tmp_df) !=0 else pd.DataFrame()
        result_df.append(tmp_stata_df)
    result_df = pd.concat(result_df, axis=0).reset_index()
    return result_df


def get_statas_df(y_true, y_pred, key, small_excep=-5, big_except=5, model_type='reg'):

    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, mean_absolute_percentage_error, f1_score, recall_score, precision_score
    ret_df = pd.DataFrame()
    if model_type in ['reg', 'regressor', 'Regressor','regression']:
        pred_diff       = y_true - y_pred
        test_MAE        = np.round(mean_absolute_error(y_true, y_pred), 4)
        test_MSE        = np.round(mean_squared_error(y_true, y_pred), 2)
        STD             = np.round(np.sqrt(mean_squared_error(y_true, y_pred)), 2)
        Abs_STD         = np.round(np.std(np.absolute(pred_diff)), 2)
        r2              = np.round(r2_score(y_true, y_pred), 2)
        mape            = np.round(mean_absolute_percentage_error(y_true, y_pred), 2)
        ted_max         = np.round(np.max(pred_diff), 2)
        ted_min         = np.round(np.min(pred_diff), 2)

        len_total       = len(y_true)
        len_small_except= len([i for i in pred_diff if i < small_excep])
        len_big_except  = len([i for i in pred_diff if i > big_except])
        ratio_small     = np.round(100.0 * len_small_except / len_total, 2)
        ratio_big       = np.round(100.0 * len_big_except / len_total, 2)

        ret_df = pd.DataFrame([[key, test_MAE, test_MSE, STD, Abs_STD, r2, mape, ted_max, ted_min, len_total, ratio_small, ratio_big]],
                              columns=['key', 'MAE', 'MSE', 'STD', 'ABS_STD', "R2", 'MAPE', 'max_diff', 'min_diff', 'Len', 'small_except_ratio', 'big_except_ratio'])

    elif model_type in ['cla', 'clf', 'cl', 'classifier']:
        f1          = np.round(f1_score(y_true, y_pred, average='weighted'), 2)
        recall      = np.round(recall_score(y_true, y_pred, average='weighted'), 2)
        precision   = np.round(precision_score(y_true, y_pred, average='weighted'), 2)
        ret_df      = pd.DataFrame([[key, f1, recall, precision]],columns=['key', 'f1_score', 'recall', 'precision'])
    else:
        logging.info('not input right model_type[%s]', model_type)

    return ret_df

def algo_quick_train( train_df,xcols,ycol,model_type, algo_names ,model_params=None):
    logging.info("begin train multi algo_names:%s",algo_names)
    models_dict={}
    for k in algo_names:  # 'KNN',  'SVM',
        logging.info(k)
        tmp_df = dropna_by_algo(train_df, k)
        model  = build_train_model(X=tmp_df[xcols].values, y=tmp_df[ycol].values, name=k, type= model_type,model_params=model_params )  # model_type:'regressor'
        if model == None: continue
        models_dict[k] = model
    logging.info("finish train multi algo_names:%s", algo_names)
    return models_dict

def single_algo_tuning_train( train_df,xcols,ycol,model_type, algo_name ,tmp_search_params,search_algo,models_dict,model_best_params ):
    logging.info("begin single_algo_tuning_train")
    tmp_df = dropna_by_algo(train_df, algo_name)
    best_params, model           = build_tuning_mode(name=algo_name, tuning_dict=tmp_search_params, X=tmp_df[xcols].values, y=tmp_df[ycol].values, type=model_type, search_algo= search_algo)  # model_type:'regressor'
    models_dict[algo_name]       = model
    model_best_params[algo_name] = best_params
    logging.info("finish single_algo_tuning_train")
    return  models_dict,model_best_params

def algo_tuning_train( train_df,xcols,ycol,model_type, algo_names ,tuning_json,search_algo,models_dict, model_best_params):
    logging.info("begin algo_tuning_train algo_names[%s] search_algo[%s] ycols[%s] xcols%s",algo_names,search_algo,ycol,xcols)
    algo_names = str_to_list(algo_names)
    tmp_search_params = json.loads(tuning_json) if isinstance(tuning_json, str) and len(tuning_json) > 0 else tuning_json if isinstance(tuning_json, dict) else None
    if len(algo_names) == 1:
        algo_name = algo_names[0]
        models_dict,model_best_params = single_algo_tuning_train( train_df,xcols,ycol,model_type, algo_name ,tmp_search_params,search_algo,models_dict,model_best_params  )
    elif len(algo_names) > 1:
        for algo_name in algo_names:
            logging.info(algo_name)
            models_dict, model_best_params = single_algo_tuning_train(train_df, xcols, ycol, model_type, algo_name, tmp_search_params, search_algo, models_dict, model_best_params)
    logging.info("finish algo_tuning_train")
    return models_dict, model_best_params

def data_type_match(data_file):
    if type(data_file) == str:
        if data_file == '':    return pd.DataFrame()
        src_df = pd.read_csv(data_file)
    if type(data_file) == pd.core.frame.DataFrame:
        src_df = data_file
    return src_df

def get_train_model( params,train_df,xcols,ycol ,use_mlflow=None):
    logging.info('begin get_train_model'       )
    logging.info('ycol:%s',ycol     )
    logging.info('params:%s',params )
    models_dict, model_best_params = {}, {}
    if use_mlflow != None:
        import mlflow
    if params.mode in  ['quick',''] :
        logging.info('params mode[%s],features:%s', params.mode,xcols)
        if  isinstance(ycol, str):ycol = ycol[0]
        algo_names  = str_to_list(params.algo_name) if params.algo_name not in ['' ,None] else ['LR', 'DT', 'Bagging', 'RandomForest', 'GBDT', 'LightGBM', 'Catboost']  # 'Xgboost',if params.mode in ['reg','regressor','regression'] else ['LR', 'Lasso', 'Ridge', 'PLS', 'ElasticNet', 'DT', 'Bagging', 'RandomForest', 'GBDT', 'LightGBM', 'Xgboost', 'Catboost']
        models_dict = algo_quick_train(train_df, xcols, ycol, model_type=params.model_type, algo_names=algo_names,model_params=params)
        logging.info('finish quick train mode')


    if params.mode in [ 'tuning',"tunning" ]:  #support multi algo
        logging.info('begin tuning train mode,features%s', xcols)
        algo_names = params.algo_name.replace(' ', '').split(',') if isinstance(params.algo_name,str) else params.algo_name
        models_dict, model_best_params = algo_tuning_train(train_df, xcols, ycol, params.model_type, algo_names, params.tuning_json, params.search_algo, models_dict, model_best_params)

        if use_mlflow != None:
            for key in model_best_params.keys():
                mlflow.log_param('%s_tuning_best_params' % key, model_best_params[key])
        logging.info('finish tuning train mode')

    if use_mlflow != None:
        logging.info('begin update LR lasso formula to mlflow')
        model_names = [i for i in models_dict.keys()]
        for idx in model_names:
            if idx in ['lr', 'LR', 'lasso', 'lasso', 'Ridge', 'ridge']:
                mlflow.log_param('%s__%s' % (idx, 'intercept'), models_dict[idx].intercept_)
                coef = models_dict[idx].coef_
                for i, v in enumerate(coef):
                    mlflow.log_param('%s__%s' % (idx, xcols[i]), v)
                    logging.info('%.6f \t Feature: %s, Score: %.5f ,%s  ' % (v, xcols[i], v, xcols[i]))
        logging.info('finish update formula to mlflow')
    logging.info('finish get_train_model')
    return models_dict,model_best_params

def evaluate_(params,models_dict,train_df,test_df,indie_df,keys,xcols,ycol,lcl=-5,BCL=5):
    logging.info('begin evaluate_ ')
    if isinstance(ycol,list):ycol =ycol[0]
    train_preds_df = multi_models_predicts(models_dict, train_df, keys=keys, xcols=xcols, ycol=ycol, data_type='train')
    #save_data(preds_df, "train_predict", params.save_dir)
    metrics_train_df = multi_preds_statas(train_preds_df, names=models_dict.keys(), ycol=ycol, small_excep=lcl, big_except=BCL, model_type=params.model_type)
    logging.info('printed train metrics result \n%s', metrics_train_df)
    # if use_mlflow != None:        mlflow.log_param(  'train_metrics', metrics_train_df['key','MAE','STD','ABS_STD',"R2".split(',')].to_json() )

    logging.info('test_df:')
    test_preds_df = multi_models_predicts(models_dict, test_df, keys=keys, xcols=xcols, ycol=ycol, data_type='test')
    #save_data(preds_df, "test_predict", params.save_dir)
    metrics_test_df = multi_preds_statas(test_preds_df, names=models_dict.keys(), ycol=ycol, small_excep=lcl, big_except=BCL, model_type=params.model_type)
    logging.info('printed test metrics result \n%s', metrics_test_df)
    # if use_mlflow != None:        mlflow.log_param(  'test_metrics',metrics_test_df.to_json()  )

    logging.info('indie_df:')
    indie_preds_df = multi_models_predicts(models_dict, indie_df, keys=keys, xcols=xcols, ycol=ycol, data_type='indie')
    #save_data(preds_df, "indie_predict", params.save_dir)
    metrics_indie_df = multi_preds_statas(indie_preds_df, names=models_dict.keys(), ycol=ycol, small_excep=lcl, big_except=BCL, model_type=params.model_type)
    logging.info('printed test metrics result \n%s', metrics_indie_df)
    # if use_mlflow != None:        mlflow.log_param(  'indie_metrics',metrics_indie_df.to_json() )
    logging.info('finish evaluate_ ')
    metrics_train_df['DType']= "train"
    metrics_test_df['DType'] =  "test"
    metrics_indie_df['DType']=  "indie"
    metrics_df      =  pd.concat([metrics_train_df,metrics_test_df,metrics_indie_df],axis=0)
    train_preds_df['DType']  = 'train'
    test_preds_df['DType']   = 'test'
    indie_preds_df['DType']  = 'indie'
    preds_df        = pd.concat( [train_preds_df,test_preds_df,indie_preds_df],axis=0 )

    return  metrics_df,preds_df

def train_singley_model(train_file, indie_file, keys, xcols, ycol, test_ratio, params, use_mlflow=None, experiment_name=''):  # 主逻辑， work_flow = 'train'  or 'deploy'
    select_cols = keys + str_to_list(ycol) + xcols
    logging.info('begin train,below is detail')
    logging.info('keys:%s', keys)
    logging.info('ycol:%s', ycol)
    logging.info('xcols:%s',xcols)
    logging.info("select_cols:%s",  select_cols)
    logging.info("train_eda:%s",    params.train_eda)
    logging.info("mode:%s",         params.mode)
    logging.info('algo_name:%s',    params.algo_name)

    if isinstance(ycol,list):
        assert not isinstance(ycol, list), "ycol cannot be list,please check!"
        return None

    if use_mlflow != None:
        import mlflow
        # run = mlflow_client.create_run(experiment_id)
        url = mlflow.get_tracking_uri()
        logging.debug('automl tracking url:%s', url)
        mlflow.log_param('keys', keys)
        mlflow.log_param('ycol', ycol)
        mlflow.log_param('xcols', xcols)
        mlflow.log_param('keys_y_x', select_cols)

    src_df      = data_type_match(train_file);      logging.info('src_df:\n%s', src_df.head(2) )
    indie_df    = data_type_match(indie_file);      logging.info('indie_df:\n%s', indie_df.head(2) )
    src_df      = src_df[select_cols]
    indie_df    = indie_df[select_cols]
    logging.info('train & indie data finished data_type_match')

    src_df            = src_df.dropna(subset=[ycol])  # has bug
    if len(indie_df) >= 1: indie_df = indie_df.dropna(subset=[ycol])

    # EDA
    if params.train_eda != None and params.train_eda !="":
        minimal         = True if params.train_eda in ['small', 'simple', 'sample'] else False  # else for example detail
        logging.info('begin eda, minimal[%s]'%minimal)
        #eda_report      = pp.ProfileReport(src_df, minimal, title=params.task_name)
        describe_df     = get_describe(src_df, indie_df, xcols, ycol)
        tmp_src_df      = src_df.dropna(subset=xcols + [ycol])
        tmp_indie_df    = indie_df.dropna(subset=xcols + [ycol])
        number_cols     = describe_df['feature'].tolist()  # (xcols + [ycol])

        psi_df          = [pd.DataFrame([[f,calc_psi(tmp_src_df, tmp_indie_df, f, params.bin_num)[0] ]], columns=["feature", "PSI"]) for f in number_cols]
        psi_df          = pd.concat(psi_df, axis=0)
        logging.info('finish eda, minimal[%s]' % minimal)

    # 数据处理  test_ratio
    if params.split_key != None and params.split_key in src_df.columns:
        logging.info('begin train_test_split,based on split_key[%s]'% params.split_key )
        split_key_list = src_df[params.split_key].unique()
        if params.get("random_state",None) == None:
            random.shuffle(split_key_list)
        test_key_list   = split_key_list[: int(len(split_key_list) * test_ratio)]
        train_df        = src_df[src_df[params.split_key].isin(test_key_list) == False]
        test_df         = src_df[src_df[params.split_key].isin(test_key_list)]
        logging.info('finsh train_test_split')

    if params.split_key == None:
        logging.info('begin train_test_split,based on test_ratio[%.2f]' % test_ratio)
        train_df, test_df = train_test_split(src_df, train_size=1 - test_ratio, random_state=params.get("random_state",None) )
        logging.info('finish train_test_split')

    if use_mlflow != None:
        logging.info('begin update src input data to mlflow')
        import datetime
        time = datetime.datetime.now();
        time_str = str(time)
        mlflow.log_param("run_time", time_str)
        mlflow.log_input(dataset=mlflow.data.from_pandas(train_df), context='raw train', tags=None)
        mlflow.log_input(dataset=mlflow.data.from_pandas(test_df), context='raw test', tags=None)
        mlflow.log_input(dataset=mlflow.data.from_pandas(indie_df), context='raw indie', tags=None)
        logging.info('finish update src input data to mlflow')

    train_df, p_dict = data_process_byparams( train_df, keys, xcols, ycol, params, True, data_type="train", use_mlflow=use_mlflow          )
    test_df          = data_process_byparams( test_df,  keys, xcols, ycol, params, False, p_dict, data_type="test", use_mlflow=use_mlflow  )
    indie_df         = data_process_byparams( indie_df, keys, xcols, ycol, params, False, p_dict, data_type="indie", use_mlflow=use_mlflow )

    if use_mlflow != None:
        logging.info('begin update after data_process input data to mlflow')
        import datetime
        import mlflow.data
        mlflow.log_input(dataset=mlflow.data.from_pandas(train_df), context='after process train',tags=None)
        mlflow.log_input(dataset=mlflow.data.from_pandas(test_df),  context='after process test', tags=None )
        mlflow.log_input(dataset=mlflow.data.from_pandas(indie_df), context='after process indie',tags=None)
        logging.info('finish update after data_process input data to mlflow')

    if 'new_add_xcols' in p_dict['onehot_dict']:
        xcols = [ i for i in xcols if i not in p_dict['onehot_dict']['new_del_xcols']] + p_dict['onehot_dict']['new_add_xcols']
        logging.info('finish update onehot_dict becauseof onehot process')

    models_dict,model_best_params   = get_train_model( params,train_df,xcols,ycol,use_mlflow  )
    metrics_df,pred_df              = evaluate_( params,models_dict,train_df,test_df,indie_df,keys,xcols,ycol )

    metrics    = params.reg_metrics.split(',')[0] if params.model_type.lower() in ['reg', 'regressor'] else params.cl_metrics.split(',')[0]
    algo_names = models_dict.keys()

    algo_names = models_dict.keys()
    candidates = set(algo_names)
    if len(set(params.model_save_candidates.split(',')) & candidates) > 0:
        candidates = set(algo_names) & set(params.model_save_candidates.split(','))

    result_dict = {}
    result_dict['train_params']     = params
    if params.train_eda is not None:
        result_dict["describe"]     = describe_df
        result_dict["psi"]          = psi_df

    result_dict['model_body']           = models_dict#{k: v for k, v in models_dict.items() if k in candidates}
    result_dict['train_test_params']    = model_best_params#{k: v for k, v in model_best_params.items() if k in candidates}  # model_best_params

    metrics_train_df                    = metrics_df[ metrics_df['DType']=='train'  ]
    metrics_test_df                     = metrics_df[ metrics_df['DType']=='test'  ]
    metrics_indie_df                    = metrics_df[ metrics_df['DType']=='indie'  ]
    result_dict['preprocess_dict']      = p_dict
    result_dict['metrics_train_df']     = metrics_train_df  # .to_string()
    result_dict['metrics_test_df']      = metrics_test_df  # .to_string()
    result_dict['metrics_indie_df']     = metrics_indie_df  # .to_string()

    ascending = params.model_type.lower() in ['reg', 'regression', 'regressor']
    result_dict['train_best_metrics']   = round(metrics_train_df.sort_values(   by=[metrics], ascending=ascending)[metrics].tolist()[0], 2)
    result_dict['test_best_metrics']    = round(metrics_test_df.sort_values(    by=[metrics], ascending=ascending)[metrics].tolist()[0], 2)
    if metrics_indie_df is not None:result_dict['indie_best_metrics']   = round(metrics_indie_df.sort_values(   by=[metrics], ascending=ascending)[metrics].tolist()[0], 2)
    result_dict['xcols']                = params.xcols
    result_dict['ycol']                 = ycol
    logging.info('begin train,up is detail')
    return result_dict

import os
def make_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)
def load_model(model_file):
    model = joblib.load(model_file)
    return model


def save_model(model, save_dir, model_file='dump_dump_dump.pkl'):
    make_dir(save_dir)
    save_file = os.path.join(save_dir, model_file)
    save_file = save_file + '.pkl' if '.pkl' not in save_file else save_file
    joblib.dump(model, save_file)
    print('save_model finished')
    return save_file


global model_params_obj
model_params_obj = None

def analy_train_save(in_args, ycol, suffix='', use_mlflow=None, experiment_name=''):
    args = copy.deepcopy(in_args)
    logging.info('begin train_singley_model,y[%s] suffix[%s] '%(ycol,suffix) )
    new_args        = copy.deepcopy(args)
    new_args.ycol   = ycol
    saved_dict = train_singley_model(new_args.train_file,
                             new_args.indie_file,
                             str_to_list(new_args.keys ),
                             str_to_list(new_args.xcols) if 'xcols' in new_args else new_args['train_params'].xcols,
                             ycol,
                             new_args.test_ratio,
                             params=new_args,
                             use_mlflow=use_mlflow,
                             experiment_name=experiment_name)

    make_dir(args.save_dir)
    if isinstance( args,dict ):
        for k in ['train_df','test_df','indie_df'] in args:
            if isinstance( args[k],pd.DataFrame  ):
                args[k] = args[k].head()
    args.task_name = args.task_name
    saved_dict['train_params'] = args
    text_file = open(os.path.join(args.save_dir, "%s__metrics_report.html" % (args.task_name + suffix)), "w")

    from pretty_html_table import build_table
    for k in ['train', 'test', 'indie']:
        html = build_table( saved_dict['metrics_%s_df' % k], 'blue_light' )  # df.head(2).to_html(classes='table table-stripped')
        text_file.write(k + '_metrics:\n');
        text_file.write(html)
        tmp_df = saved_dict['metrics_%s_df' % k];
        tmp_df['data_type'] = k
        write_model = 'w' if k == 'train' else 'a'
        tmp_df.to_csv(os.path.join(args.save_dir, "%s__metrics.csv" % (args.task_name + suffix)), mode=write_model,index=False)
    if 'eda_report' in saved_dict:
        html = build_table(saved_dict["psi"], "blue_light");
        text_file.write("PSI:\n");
        text_file.write(html)
        html = build_table(saved_dict["describe"], "blue_light");
        text_file.write("describe:\n");
        text_file.write(html)
    text_file.close()

    if 'eda_report' in saved_dict:
        saved_dict['eda_report'].to_file(os.path.join(args.save_dir, "%s__eda_report.html" % (args.task_name + suffix)))

    if use_mlflow != None:
        import mlflow
        mlflow.log_artifact(os.path.join(args.save_dir, "%s__metrics_report.html" % (args.task_name + suffix)), artifact_path='report')  # metrics
        #mlflow.log_artifact(os.path.join(args.save_dir, "%s__eda_report.html" % (args.task_name + suffix)), artifact_path='report')  # EDA

    saved_dict = {k: v for k, v in saved_dict.items() if k not in ['eda_report']};
    logging.info('train_singley_model finished,and report saved ')
    return saved_dict

def predict_logic(model_params_obj, sample_df):
    sample_df =  data_type_match( sample_df )
    if isinstance(model_params_obj, dict):
        logging.info('one model')
        model_dict = model_params_obj
        keys = [i for i in sample_df.columns if i not in model_dict['xcols'] and i != model_dict['ycol']]
        preds_df = predict_singley(model_dict['model_body'],
                                   sample_df,
                                   str_to_list(model_dict['train_params'].keys),
                                   model_dict['xcols'] if 'xcols' in model_dict else model_dict['train_params'].xcols,  # .xcols,
                                   model_dict['ycol'] if 'ycol' in model_dict else model_dict['train_params'].ycol,  # .ycol
                                   model_dict['train_params'],
                                   model_dict['preprocess_dict'])
        ret_df = preds_df  # pd.merge( sample_df[keys], preds_df,on=keys,how='left'  )
    if isinstance(model_params_obj, list):
        logging.info('begin multi model predict')
        preds_list = []
        ret_df = pd.DataFrame()
        for model_dict in model_params_obj:
            preds_df = predict_singley(model_dict['model_body'],
                                       sample_df,
                                       str_to_list(model_dict['train_params'].keys),
                                       model_dict['xcols'] if 'xcols' in model_dict else model_dict['train_params'].xcols,  # .xcols,
                                       model_dict['ycol'] if 'ycol' in model_dict else model_dict['train_params'].ycol,  # .ycol
                                       model_dict['train_params'],
                                       model_dict['preprocess_dict'])
            preds_col = list(model_dict['model_body'].keys())[0]
            preds_df = preds_df.rename(columns={preds_col: model_dict['ycol']})

            logging.info('preds_df', preds_df.head(1))
            keys = [i for i in sample_df.columns if i not in model_dict['xcols'] and i != model_dict['ycol'] and i in preds_df.columns ]
            logging.info('keys %s', keys)
            if len(ret_df.columns) == 0: ret_df = preds_df[keys]
            ret_df = pd.merge(ret_df, preds_df, on=keys, how='left')
        logging.info('finish multi model predict')
    return ret_df


def train_logic( args,use_mlflow,experiment_name  ) :
    logging.info("begin train logic, depands on  one_ycol/multi_ycol. [%s] ", args.ycol)
    if isinstance(args.ycol, str) and len(  str_to_list(args.ycol) )==1:

        result_dict = analy_train_save(args, args.ycol, use_mlflow=use_mlflow, experiment_name=experiment_name)  # dict object
        ret_obj     = result_dict
    if isinstance(args.ycol, list)  or len(  str_to_list(args.ycol) )>1:
        logging.info('begin train multi y[%s]' % ','.join(args.ycol) )
        args.train_eda = 'simple'
        if use_mlflow != None:
            import mlflow
            mlflow.log_param('multi_y', ','.join(args.ycol) )
            mlflow.log_param('x', args.xcols )
        ret_obj = []
        ycols   = str_to_list(args.ycol)
        for i_y in ycols:
            result_dict = analy_train_save(args, i_y, suffix='__' + i_y)  # ,experiment_name=experiment_name
            ret_obj.append(result_dict)
        logging.info('finish train multi y[%s]' % ','.join(args.ycol))
    logging.info("finish train logic")
    return ret_obj

def main_logic( args, use_mlflow=None, experiment_name='' ):
    logging.debug('begin our flow,args:%S', args)
    time        = datetime.datetime.now();
    time_str    = str(time)
    if args.task == 'train':
        ret_obj = train_logic( args,use_mlflow ,experiment_name )
        save_file = save_model(ret_obj, save_dir=args.save_dir, model_file=args.task_name + '.ckp')  #pkl
        if use_mlflow != None:
            import mlflow
            mlflow.log_artifact(save_file, artifact_path='model')
        return ret_obj

    if args.task == 'predict':
        global model_params_obj
        if args.sample_df == None:
            logging.error('no sample data ,please check')

        if type(args.predict_rely_file) == str and model_params_obj == None:
            model_params_obj = load_model_and_paras(args.predict_rely_file)
            logging.info('first load model_params_obj:%s', model_params_obj)
        if (isinstance(args.predict_rely_file, dict) or isinstance(args.predict_rely_file, list)) and model_params_obj == None:
            model_params_obj = args.predict_rely_file
        preds = predict_logic(model_params_obj, args.sample_df)
        logging.info( 'automl predict result:\n%s', preds )
        return preds

from ..data_process.data_preprocess import data_process_byparams
def predict_singley(models, inf_df, keys, xcols, ycol, paras, preprocess_dict):
    keys  = str_to_list(keys)
    xcols = str_to_list(xcols)
    inf_df= inf_df[ keys+xcols ]
    logging.info('begin  predict_singley,keys%s xcols%s',  keys, xcols)
    inf_df = data_type_match(inf_df)

    left_keys = [i for i in inf_df.columns if i not in xcols and i != ycol]
    keys = keys + [i for i in left_keys if i not in keys]
    logging.info('left_keys:%s', left_keys)
    inf_df = data_process_byparams( inf_df, keys, xcols, ycol, paras, False, preprocess_dict, data_type="predict" )
    logging.info( 'inf_df:\n%s', inf_df )
    if 'new_add_xcols' in preprocess_dict['onehot_dict']:
        xcols = [ i for i in xcols if i not in preprocess_dict['onehot_dict']['new_del_xcols']] + preprocess_dict['onehot_dict']['new_add_xcols']
    preds = multi_models_predicts(models, inf_df, keys, xcols, ycol, deploy=True)
    logging.info('preds:\n%s', preds.head(5))
    logging.info('finish predict_singley,keys%s   xcols%s',  keys, xcols)
    return preds


import re
def calc_derive_feature(func_body, raw_df, derive_cfg_df):
    if isinstance(raw_df, str):
        raw_df = pd.read_csv(raw_df)
    func_name = re.findall(r"^def +(.+?)\(", func_body)[0]
    exec(func_body, globals())
    derived_df = eval(func_name)(raw_df, derive_cfg_df)  # site_level_cols, wafer_level_cols
    return derived_df

def load_model_and_paras(model_params_path):
    ret = joblib.load(model_params_path)
    return ret
def set_args():
    parser = argparse.ArgumentParser()
    # parser.add_argument('--device',                   default='1',                type=str, required=False, help='设置使用哪些显卡')
    # parser.add_argument('--no_cuda',                  action='store_true',  help='不使用GPU进行训练')
    subparsers = parser.add_subparsers(dest='task')  # train / predict
    train_parser = subparsers.add_parser('train')
    train_parser.add_argument('--task_name',    default='fill_tastk_name', type=str, required=False, help='task name')
    train_parser.add_argument('--mode',         default='quick', type=str, required=True, help='quick,tuning')
    train_parser.add_argument('--model_type',   default='regressor', type=str, required=True, help='regressor/cla,clf,classifier or reg,regressor')
    train_parser.add_argument('--tuning_json',  default=None, type=str, required=False, help='params json for tuning single algo')
    train_parser.add_argument('--search_algo',  default='gridsearch', type=str, required=False, help='choose gridsearch/tpe/random')
    train_parser.add_argument('--keys',         default='LOT_ID,WAFERNO', type=str, required=True, help='The key columns')
    train_parser.add_argument('--xcols',        default=',,,', type=str, required=True, help='features input')
    train_parser.add_argument('--ycol',         default='', type=str, required=True, help='output')
    train_parser.add_argument('--train_file',   default='./input_data/**.csv', type=str, required=True, help='site model path')
    train_parser.add_argument('--indie_file',   default='', type=str, required=False, help='independ set data path')

    train_parser.add_argument('--save_dir',     default='./out_dir/', type=str, required=False, help='site save dir')
    train_parser.add_argument('--train_dump_name', default='train_dump_file.ckp', type=str, required=False, help='filename for dump train model')

    train_parser.add_argument('--train_eda',    default=None, type=str, required=False, help='simple/detail')
    train_parser.add_argument('--split_key',    default='LOT_ID', type=str, required=True, help='The split reference(LOT_NO, WAFER_NO,TIME)')
    train_parser.add_argument('--test_ratio',   default=0.2, type=float, required=False, help='The split ratio')

    train_parser.add_argument('--except_sigma_for_y',   default=10, type=float, required=False, help='sigma')
    train_parser.add_argument('--except_sigma_for_num', default=10, type=float, required=False, help='except_sigma_for_numberic')

    train_parser.add_argument('--y_scope_begin',    default=None, type=float, required=False, help='')
    train_parser.add_argument('--y_scope_end',      default=None, type=float, required=False, help='')
    train_parser.add_argument('--cat_cols',         default=None, type=str, required=False, help='output')

    train_parser.add_argument('--oversample_y_begin', default=None, type=float, required=False, help='')
    train_parser.add_argument('--oversample_y_end', default=None, type=float, required=False, help='')
    train_parser.add_argument('--oversample_ratio', default=None, type=float, required=False, help='')

    ##nan fillna
    train_parser.add_argument('--removena_num_cols', default=None, type=str, required=False, help='fillna with lot_mean')
    # train_parser.add_argument('--numberic_fillna',     default=None, type=str, required=False, help='lot_mean,chamber_mean,product_mean,chamber_line,mean')
    # train_parser.add_argument('--category_fillna',     default=None, type=str, required=False, help='mode_value,as_another_label')

    train_parser.add_argument('--onehot_cols', default=None, type=str, required=False, help='')
    train_parser.add_argument('--ordinal_cols', default=None, type=str, required=False, help='')
    train_parser.add_argument('--zscore_cols', default=None, type=str, required=False, help='')
    train_parser.add_argument('--zscore_cut', default=2, type=str, required=False, help='')
    train_parser.add_argument('--norm_cols', default=None, type=str, required=False, help='')
    train_parser.add_argument('--divmax_cols', default=None, type=str, required=False, help='')
    train_parser.add_argument('--log_cols', default=None, type=str, required=False, help='')

    train_parser.add_argument('--algo_name', default='LR', type=str, required=False, help='LR,Lasso,Ridge,Xgboost,LightGBM,PLS,Catboost,ElasticNet,DT')

    train_parser.add_argument('--reg_metrics', default='MAE', type=str, required=False, help='MAE,MSE')
    train_parser.add_argument('--cl_metrics', default='f1_score', type=str, required=False, help='precision,recall,f1_score')

    train_parser.add_argument('--train_save_ul', default=None, type=float, required=False, help='model_save less than')
    train_parser.add_argument('--train_save_ll', default=None, type=float, required=False, help='model_save more than')
    train_parser.add_argument('--test_save_ul', default=None, type=float, required=False, help='model_save less than')
    train_parser.add_argument('--test_save_ll', default=None, type=float, required=False, help='model_save more than')
    train_parser.add_argument('--indie_save_ul', default=None, type=float, required=False, help='model_save less than')
    train_parser.add_argument('--indie_save_ll', default=None, type=float, required=False, help='model_save more than')

    train_parser.add_argument('--bcl',          default=None, type=float, required=False, help='BCL:big control line')
    train_parser.add_argument('--lcl',          default=None, type=float, required=False, help='lcl: low controal line')
    train_parser.add_argument('--model_save_candidates', default='LR,Ridge,Lasso,PLS,Xgboost,LightGBM', type=str, required=False, help=',,')  # catboost,RandomForest  ,
    train_parser.add_argument("--bin_num",      default=10, type=int, required=False, help="number of bins for calculating PSI")

    predict_parser = subparsers.add_parser('predict')
    predict_parser.add_argument('--predict_rely_file',  default=None, type=str, required=False, help='provide the right pickfile')
    predict_parser.add_argument('--sample_df',          default=None, type=str, required=False, help='provide the feature value data')
    predict_parser.add_argument('--task_name',          default='fill_tastk_name', type=str, required=False, help='task name')
    predict_parser.add_argument('--preprocess_json',    default=None, type=str, required=False, help='user proc json')

    args = parser.parse_args()
    return args

if __name__ == '__main__':
    args = set_args( )
    logging.info('begin main_logic args:%s',args )
    main_logic(args)

    #请为这段代码增加该有的日志，一些不合理的print进行精简，并对可能的报错返回提示，以方便问题定位
    # elif params.mode == 'multi_y' and isinstance(ycol, list):
    #     logging.info("begin multi y train:")
    #     algo_names = str_to_list(params.algo_name)[0] if params.algo_name not in ['' ,None] else "LightGBM"
    #     for iter in ycol:
    #         logging.info(iter)
    #         tmp_df              = dropna_by_algo(train_df, algo_names )
    #         model               = build_train_model(X=tmp_df[xcols].values, y=tmp_df[iter].values, name='LightGBM', type=params.model_type)  # model_type:'regressor'
    #         models_dict[ iter ] = model
  
  