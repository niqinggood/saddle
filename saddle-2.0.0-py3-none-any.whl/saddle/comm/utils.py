import json
from datetime import datetime, timedelta
import time as time_u
from .time import str2time,str2date
import configparser
import socket
import os
import sys
try:
    # 性能 10000次转换耗时：0.00976705551147461
    from ciso8601 import parse_datetime
except ImportError as e:
    # 性能 10000次转换耗时：2.91825270652771
    from dateutil.parser import parse as parse_datetime

minTime = lambda t1,t2: t1 if t1<t2 else t2
maxTime = lambda t1,t2: t1 if t1>t2 else t2

def get_token(token=None,token_file=None):
    if token !=None:
        return token
    with open(token_file,'r' ) as file:
        Token = file.read().strip('\n')
        return Token

def getConfig(filename):
    #获取config配置文件
    config = configparser.ConfigParser()
    # 如果是win平台使用程序目录下的配置，因win目录下的配置应该只会用于测试
    sys_name = os.name
    path = ''
    # 允许外面指定config文件，因pycharm2016.3开始argv参数顺序调整，
    # 导致argv[1]不再是传入的config.ini参数，采用遍历取ini文件为配置
    for f in sys.argv:
        if f.endswith('.ini'):
            path = f
            break
    if not path:
        if sys_name == 'nt':
            path = os.path.split(os.path.realpath(filename))[0] + '\\config.ini'
        elif sys_name == 'posix':
            dirName = os.path.split(os.path.realpath(filename))[0].split('/')
            # /etc/maxwin/sync_db2redis/config.ini ,专案名为 sync_db2redis
            prjname = dirName[len(dirName) - 1]
            path = '/etc/maxwin/%s/config.ini' % prjname
        else:
            path = '/etc/maxwin/anlysetrip/config.ini'
    config.read(path)
    return config

def oneDay():
    return timedelta(days=1)

def oneHour():
    return timedelta(hours=1)

def none2default(val,NoneVal):
    return val if val else NoneVal

def getSec(time):
    return time.hour*60*60+time.minute*60+time.second if time else 0

def dateAddTime(adate,atime):
    if isinstance(adate,str):
        ndate = str2date(adate)
    else:
        ndate = adate
    if isinstance(atime,str):
        ntime = str2time(atime)
    else:
        ntime = atime
    return datetime.combine(ndate,ntime)

def datetimeAddSec(adatetime,aseconds):
    return adatetime + timedelta(seconds=aseconds)

def datetimeReduceSec(adatetime,aseconds):
    return adatetime - timedelta(seconds=aseconds)

def toUTCtime(dt):
    if dt:
        return int(dt.timestamp())
    else:
        return time_u.timezone

def bool2redis(val):
    return -1 if val else 0

def hostname():
    return socket.gethostname()

def hex2dec(string_num):
    string_num = string_num.replace("0x", "")
    return int(string_num.upper(), 16)


def h2d(string_num):
    string_num = string_num.replace("0x", "")
    if not string_num.isdigit():
        return None
    return int(string_num.upper(), 16)

import logging
import os
from logging.handlers import TimedRotatingFileHandler


class ContextFilter(logging.Filter):
    def __init__(self, username):
        super().__init__()
        self.username = username

    def filter(self, record):
        record.username = self.username
        return True


import os
import logging
from logging.handlers import TimedRotatingFileHandler

def mk_dir(dir_path):
    """创建目录（如果目录不存在）"""
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)

def set_logging(log_dir, file_name, mode='prod', twhen='midnight', interval=1, backupcnt=7):
    # 定义日志格式
    if mode == 'prod':
        fmt = '[%(asctime)s] %(message)s'  #[%(levelname)s][%(name)s]
    elif mode in ['debug', 'dev']:
        fmt = '[%(asctime)s][%(levelname)s][%(filename)s:%(lineno)s-%(name)s] %(message)s'
    else:
        fmt = '[%(asctime)s][%(levelname)s] %(message)s'

    # 创建日志目录
    mk_dir(log_dir)

    # 构建日志文件路径
    log_file_path = os.path.join(log_dir, f"{file_name}.log")

    # 配置根日志记录器
    logging.basicConfig(level=logging.INFO, format=fmt,datefmt='%Y%m%d %H:%M:%S', force=True)

    # 获取根日志记录器
    root_logger = logging.getLogger()

    # 检查并移除重复的处理器
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # 创建控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    # 设置控制台处理器的格式
    fmt2 = logging.Formatter(fmt=fmt,datefmt='%Y%m%d %H:%M:%S')
    console_handler.setFormatter(fmt2)

    # 创建每日轮转的文件处理器
    file_handler = TimedRotatingFileHandler(
        log_file_path,  # 日志文件路径
        when=twhen,     # 轮转时间（midnight 表示每天午夜）
        interval=interval,  # 轮转间隔
        backupCount=backupcnt  # 保留的日志文件数量
    )
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(fmt2)

    # 将控制台处理器和文件处理器添加到根日志记录器
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)

    return log_file_path
# def set_logging(log_dir, file_name,  mode='prod', twhen='midnight', interval=1, backupcnt=7):
#     # 定义日志格式
#     # [%(username)s]
#     if mode == 'prod':
#         fmt = '[%(asctime)s][%(levelname)s][%(name)s] %(message)s'
#     elif mode in ['debug', 'dev']:
#         fmt = '[%(asctime)s][%(levelname)s][%(filename)s:%(lineno)s-%(name)s] %(message)s'
#     else:
#         fmt = '[%(asctime)s][%(levelname)s] %(message)s'
#
#     # 创建日志目录
#     mk_dir(log_dir)
#
#     # 构建日志文件路径
#     log_file_path = os.path.join(log_dir, f"{file_name}.log")
#
#     # 配置根日志记录器
#     logging.basicConfig(level=logging.INFO, format=fmt, force=True)
#
#     # 获取根日志记录器
#     root_logger = logging.getLogger()
#
#     # 检查并移除重复的处理器
#     for handler in root_logger.handlers[:]:
#         root_logger.removeHandler(handler)
#
#     # 创建控制台处理器
#     console_handler = logging.StreamHandler()
#     console_handler.setLevel(logging.INFO)
#
#     # 设置控制台处理器的格式
#     fmt2 = logging.Formatter(fmt)
#     console_handler.setFormatter(fmt2)
#
#     # 创建每日轮转的文件处理器
#     #file_handler = TimedRotatingFileHandler(log_file_path, when=twhen, interval=interval, backupCount=backupcnt)
#     #file_handler.setLevel(logging.INFO)
#     #file_handler.setFormatter(fmt2)
#
#     # # 添加自定义过滤器
#     # if username is not None:
#     #     context_filter = ContextFilter(username)
#     #     root_logger.addFilter(context_filter)
#
#     # 将控制台处理器和文件处理器添加到根日志记录器
#     root_logger.addHandler(console_handler)
#     #root_logger.addHandler(file_handler)
#
#     return log_file_path

import pandas as pd
def append_file( file_path, content, mode = 'a' ):
    with open(file_path,mode ) as file:
        file.write(content)


def remove_file(file):
    if (os.path.exists(file)):
        os.remove(file)

def getFileList(src_file_dir=None,src_file_name=None):
    import glob
    if src_file_dir==None or src_file_name==None or src_file_dir=="":
        print(  "filelist is null" )
        return []
    dir_str_len=len(src_file_dir)
    if '/'==src_file_dir[dir_str_len-1]:
        file_list = glob.glob("%s%s" % (src_file_dir,src_file_name))
    else:
        file_list = glob.glob("%s/%s" % (src_file_dir,src_file_name))
    return file_list

def remove_dir_file(src_dir):
    file_list = getFileList(src_dir, "*")
    for file in file_list:
        remove_file(file)
    return 0

import logging
def  delete_directory(directory):
    if not os.path.exists(directory):
        logging.info("Direcotry %s does not exist.",directory)
    for root, dirs, files in os.walk( directory,topdown=False):
        for name in files:
            filename = os.path.join( root,name )
            os.remove(filename)
        for name in dirs:
            dirname = os.path.join( root,name )
            os.rmdir( dirname )
    os.rmdir(directory)

import shutil
def copy_file(src_file, dest_file):
    if os.path.exists(src_file):
        shutil.copy(src_file, dest_file)
        return dest_file
    return

def copy_directory(src, dst):
    try:
        # 如果目标目录存在，先删除它
        if os.path.exists(dst):
            shutil.rmtree(dst)
            print(f"Existing directory {dst} has been removed.")
        # 复制目录
        shutil.copytree(src, dst)
        print(f"Directory copied from {src} to {dst}")
    except Exception as e:
        print(f"An error occurred: {e}")


def copy_directory_into(src, dst):
    try:
        # 确保目标目录存在
        if not os.path.exists(dst):
            os.makedirs(dst)

        # 遍历源目录中的所有文件和子目录
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)

            if os.path.isdir(s):
                # 如果是子目录，递归复制
                shutil.copytree(s, d, dirs_exist_ok=True)
            else:
                # 如果是文件，直接复制
                shutil.copy2(s, d)

        print(f"Directory copied from {src} into {dst}")
    except Exception as e:
        print(f"An error occurred: {e}")


def copy_directory_as_subdirectory(src, dest):
    try:
        # 确保目标目录存在
        if not os.path.exists(dest):
            os.makedirs(dest)

        # 构建目标目录中 src 子目录的路径
        dest_subdir = os.path.join(dest, os.path.basename(src))

        # 复制目录
        shutil.copytree(src, dest_subdir)
        print(f"Directory {src} copied as a subdirectory into {dest}")
    except Exception as e:
        print(f"An error occurred: {e}")

# origin_file_index=src_file.rfind("/")
# return des_dir+src_file[origin_file_index+1:]
def make_dir(path):
    import os
    if not os.path.exists(path):
        os.makedirs(path)
def mk_dir(path):
    import os
    if not os.path.exists(path):
        os.makedirs(path)



def get_ini_conf( config_path ):
    import configparser
    conf  = configparser.ConfigParser()
    conf.read(config_path)
    return conf

def dict_to_xml(input_dict):
    import xmltodict
    xml  = xmltodict.unparse( input_dict,encoding='GB2312',full_document=False )
    return xml
def xml_to_dict(xml_content):
    import xmltodict
    xml_par         = xmltodict.parse(xml_content)
    json_content    = json.dumps( xml_par,indent=1 )
    return json_content

import argparse
import logging
import copy
def map_to_localargs(r_c):
    #    preprocess_json  :   { "字段": {  "inout_type"/"data_type":num /scalar/ cat ,
    #                                      "proc"  : minmax/log/zscore  or ordinal/onehot/label/onehot/remove,
    #                                      "fillna": proc_method
    #                                      "batch" : proc_method }

    logging.info('begin map_to_localargs')
    r_c = {k.lower(): v for k, v in r_c.items()}
    logging.info(f"r_c detail:{r_c}")
    if 'preprocess' in r_c:
        r_c['preprocess_json'] = r_c['preprocess']
    new_dict = {}
    if 'preprocess_json' in r_c:
        r_c['zscore_cols']      = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') == 'num') and 'procproc' in v and v['proc'] == 'zscore']
        r_c['norm_cols']        = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') == 'num') and 'proc' in v and v['proc'] in [ 'norm','minmaxscaler'] ]
        r_c['divmax_cols']      = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') == 'num') and 'proc' in v and v['proc'] == 'divmax']
        r_c['log_cols']         = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') == 'num') and 'proc' in v and v['proc'] == 'log']
        r_c['ordinal_cols']     = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') in ['cat','scalar']) and 'proc' in v and v['proc'] == 'ordinal']
        r_c['onehot_cols']      = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') in ['cat','scalar']) and 'proc' in v and v['proc'] == 'onehot']
        r_c['labelencoder_cols']= [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') in ['cat','scalar']) and 'proc' in v and v['proc'] == 'label']
        r_c["removena_num_cols"]= [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') == 'num') and "fillna" in v and v["fillna"] in [ "remove_nan","remove"] ]

    new_dict =  { i:r_c[i] for i in r_c }
    new_dict.setdefault('tuning_json', '');
    new_dict.setdefault('search_algo', 'TPE');
    new_dict.setdefault('train_eda', 'detail');
    new_dict.setdefault('split_key', 'LOT_ID');
    new_dict.setdefault('test_ratio', 0.2);
    new_dict.setdefault('except_sigma_for_num', 5);
    new_dict.setdefault('except_sigma_for_y', 5);
    new_dict.setdefault('reg_metrics', 'MAE');
    new_dict.setdefault('cl_metrics', 'f1-score');
    new_dict.setdefault('model_save_candidates', 'LR,Ridge,Lasso,PLS,Xgboost,LightGBM,Catboost');
    new_dict.setdefault('bin_num', 10)
    new_dict.setdefault('preprocess_json', '')
    new_dict.setdefault("batchfill", None )
    new_dict.setdefault("groupfill", None )
    new_dict.setdefault("sample_y_begin",None)
    if 'keys' in new_dict and (new_dict['keys'] is None or new_dict["keys"] == 'NoneType'):  new_dict['keys'] = []

    args = argparse.Namespace(**new_dict)
    logging.info('finish map_to_localargs:%s',args)
    return args

if __name__ == '__main__':
    a = if_time1_later('20220102','20220103')
    print('a:',a)